# !/bin/sh
rm 9.7.log 9.7.o.log  

p=1
for i in `seq 2 41`;
do
    mpiexec -n ${i} ./9.7  100000 2000 >> 9.7.log  
    echo ${i} processes done
done

cat 9.7.log | grep Time | awk '{print $3}' >> 9.7.o.log 
